exports.txtSewabot = (prefix) => {
return `
 1-Minggu : Rp5.000
 2-Minggu : Rp.10.000
 1-Bulan : Rp.20.000
 2-Bulan : Rp.30.000
 3-Bulan : Rp40.000
`
}
exports.txtDonate = (prefix) => {
return `
▷_*DONASI BOT*_
 _- DANA : 08xxxxxxxx_
 _- OVO : 08xxxxxxxx_
 _- GOPAY : 08xxxxxxxx_
 _- QRIS : https://bit.ly/3yy0qoZ_
`
}